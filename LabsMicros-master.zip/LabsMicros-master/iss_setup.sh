#!/bin/bash

export DEVKIT=/opt/iot-devkit/devkit-x86
export PATH=$PATH:$DEVKIT/sysroots/x86_64-pokysdk-linux/usr/bin/i586-poky-linux
export CROSS_COMPILE=i586-poky-linux-
