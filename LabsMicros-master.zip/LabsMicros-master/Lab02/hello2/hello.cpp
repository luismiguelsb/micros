#include <iostream>
using namespace std;

int main(int argc,char *argv[])
{
	cout << "Hello, world!" << endl;

	return 0;
}
