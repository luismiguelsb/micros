var searchData=
[
  ['voltage_5fto_5fdutycycle',['voltage_to_dutycycle',['../quanser_8h.html#a0fe19e4d1a390f811ceae0ca8e53bcb9',1,'voltage_to_dutycycle(float voltage):&#160;quanser.c'],['../quanser_8c.html#a0fe19e4d1a390f811ceae0ca8e53bcb9',1,'voltage_to_dutycycle(float voltage):&#160;quanser.c']]]
];
