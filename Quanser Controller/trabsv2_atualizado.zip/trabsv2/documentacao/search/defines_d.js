var searchData=
[
  ['write_5fmdr0',['WRITE_MDR0',['../sensors_8h.html#a73c9ba0cf0643be60bbb546c7a7afe6e',1,'sensors.h']]],
  ['write_5fmdr1',['WRITE_MDR1',['../sensors_8h.html#a0698ef7218887ec46cf9b0c54691048b',1,'sensors.h']]]
];
