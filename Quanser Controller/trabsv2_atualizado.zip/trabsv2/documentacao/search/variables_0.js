var searchData=
[
  ['devspi',['devspi',['../sensors_8h.html#a6c307f9a51e6bf3d140869a67a7c2d4e',1,'sensors.h']]]
];
