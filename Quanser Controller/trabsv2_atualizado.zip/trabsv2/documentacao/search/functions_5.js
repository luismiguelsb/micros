var searchData=
[
  ['limitswitch',['limitSwitch',['../sensors_8h.html#a50ab4257cb286176e196ccc51d31fc59',1,'limitSwitch(int which_switch):&#160;sensors.c'],['../sensors_8c.html#a50ab4257cb286176e196ccc51d31fc59',1,'limitSwitch(int which_switch):&#160;sensors.c']]]
];
