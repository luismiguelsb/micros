var searchData=
[
  ['limitswitch',['limitSwitch',['../sensors_8h.html#a50ab4257cb286176e196ccc51d31fc59',1,'limitSwitch(int which_switch):&#160;sensors.c'],['../sensors_8c.html#a50ab4257cb286176e196ccc51d31fc59',1,'limitSwitch(int which_switch):&#160;sensors.c']]],
  ['lower_5fdutycycle',['LOWER_DUTYCYCLE',['../quanser_8h.html#ab8635b58c4f688d0bb0a4cc4bc240460',1,'quanser.h']]],
  ['lower_5fvoltage',['LOWER_VOLTAGE',['../quanser_8h.html#a158aa655f844a98c973039591166869b',1,'quanser.h']]]
];
