var searchData=
[
  ['tensaopid',['tensaoPID',['../quanser_8h.html#a08e1b1af958a529981c82dd19547bb5f',1,'tensaoPID(float dt, float currentAngle):&#160;quanser.c'],['../quanser_8c.html#a08e1b1af958a529981c82dd19547bb5f',1,'tensaoPID(float dt, float currentAngle):&#160;quanser.c']]]
];
