var searchData=
[
  ['higher_5fdutycycle',['HIGHER_DUTYCYCLE',['../quanser_8h.html#a0c0c815ecfc5cef6add23144b45568bb',1,'quanser.h']]],
  ['higher_5fvoltage',['HIGHER_VOLTAGE',['../quanser_8h.html#a5095409d9f18f51d8b0bf38f51d1cf11',1,'quanser.h']]]
];
