var searchData=
[
  ['read_5fcntr',['READ_CNTR',['../sensors_8h.html#a16f3c4a685121a0c5ae673d5dc51ce79',1,'sensors.h']]]
];
