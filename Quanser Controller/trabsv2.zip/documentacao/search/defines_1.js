var searchData=
[
  ['clr_5fcntr',['CLR_CNTR',['../sensors_8h.html#a16c48d94cd722a9b80c88ea5403fe32a',1,'sensors.h']]]
];
