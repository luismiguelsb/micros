var searchData=
[
  ['devspi',['devspi',['../sensors_8h.html#a6c307f9a51e6bf3d140869a67a7c2d4e',1,'sensors.h']]],
  ['diffpid',['diffPID',['../quanser_8h.html#abd4b31d8bbe5297514933f381132da40',1,'diffPID():&#160;quanser.c'],['../quanser_8c.html#abd4b31d8bbe5297514933f381132da40',1,'diffPID():&#160;quanser.c']]],
  ['disable_5findx',['DISABLE_INDX',['../sensors_8h.html#a9c85cd3313959f783e982dc29f5894b4',1,'sensors.h']]]
];
