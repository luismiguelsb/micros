var searchData=
[
  ['closedecoder',['closeDecoder',['../sensors_8h.html#a4789a8de73a10799d869cf07f32f74ca',1,'closeDecoder():&#160;sensors.c'],['../sensors_8c.html#a4789a8de73a10799d869cf07f32f74ca',1,'closeDecoder():&#160;sensors.c']]],
  ['clr_5fcntr',['CLR_CNTR',['../sensors_8h.html#a16c48d94cd722a9b80c88ea5403fe32a',1,'sensors.h']]]
];
