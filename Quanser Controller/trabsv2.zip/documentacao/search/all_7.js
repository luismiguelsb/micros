var searchData=
[
  ['initpid',['initPID',['../quanser_8h.html#a229194cc59049acbc674e3fd2e3e3f17',1,'initPID(float initialAngle, float finalAngle):&#160;quanser.c'],['../quanser_8c.html#a229194cc59049acbc674e3fd2e3e3f17',1,'initPID(float initialAngle, float finalAngle):&#160;quanser.c']]]
];
