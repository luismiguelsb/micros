var searchData=
[
  ['quadrx1',['QUADRX1',['../sensors_8h.html#a56cb489ea18306c755ca95aaab835749',1,'sensors.h']]],
  ['quadrx4',['QUADRX4',['../sensors_8h.html#af409c8fda3b8fee55811fb024cb030a6',1,'sensors.h']]]
];
