var searchData=
[
  ['sensors_2ec',['sensors.c',['../sensors_8c.html',1,'']]],
  ['sensors_2eh',['sensors.h',['../sensors_8h.html',1,'']]],
  ['setmotorvoltage',['setMotorVoltage',['../quanser_8h.html#a984aa9f0aff2ba2d5490c6481652cd45',1,'setMotorVoltage(float value):&#160;quanser.c'],['../quanser_8c.html#a984aa9f0aff2ba2d5490c6481652cd45',1,'setMotorVoltage(float value):&#160;quanser.c']]],
  ['setupdecoder',['setupDecoder',['../sensors_8h.html#a5dfbc0ea8690527307c36e4894f9e28c',1,'setupDecoder():&#160;sensors.c'],['../sensors_8c.html#a5dfbc0ea8690527307c36e4894f9e28c',1,'setupDecoder():&#160;sensors.c']]]
];
